package com.example.silentshutter

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    // 삼성 CSC 설정 키: 0 = 셔터음 끔, 1 = 셔터음 켬
    private val key = "csc_pref_camera_forced_shuttersound_key"
    private lateinit var sw: Switch
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(64, 64, 64, 64)
        }
        sw = Switch(this).apply { text = "카메라 무음"; textSize = 22f }
        status = TextView(this).apply { textSize = 14f; setPadding(0, 32, 0, 0) }
        root.addView(sw); root.addView(status)
        setContentView(root)

        sw.setOnCheckedChangeListener { v, checked ->
            if (!v.isPressed) return@setOnCheckedChangeListener
            if (!Settings.System.canWrite(this)) { askPermission(); sw.isChecked = !checked; return@setOnCheckedChangeListener }
            try {
                Settings.System.putString(contentResolver, key, if (checked) "0" else "1")
            } catch (e: Exception) {
                Toast.makeText(this, "실패: ${e.message}", Toast.LENGTH_LONG).show()
            }
            refresh()
        }
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun askPermission() {
        Toast.makeText(this, "'시스템 설정 수정 허용'을 켜주세요", Toast.LENGTH_LONG).show()
        startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
    }

    private fun refresh() {
        val v = Settings.System.getString(contentResolver, key)
        sw.isChecked = (v == "0")
        status.text = "현재 값: ${v ?: "없음"} / 권한: ${if (Settings.System.canWrite(this)) "허용됨" else "필요"}"
    }
}
